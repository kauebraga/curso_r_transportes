# Inicializa��o ----

## Define bibliotecas ----

library(jsonlite)
library(RCurl)
library(dplyr)
library(data.table)
library(sf)
library(nngeo)

### Desativa pacote para evitar erros.

detach("package:plyr", unload=TRUE)

## Define diretorio de trabalho ----

setwd("D:/gtfs_rio")

# Ag�ncia -----------------------------------------------------------------

##### Obtem dado usando API do SIGMOB. Seleciona a tabela de resultado. Remove tabela bruta.
##### Faz o filtro para manter apenas colunas desejadas. Mantem apenas agencia BRT Rio.
##### Escreve tabela filtrada.

dado <- fromJSON(getURL("http://jeap.rio.rj.gov.br/MOB/get_agency.rule?sys=MOB&INDICE=0",
                        .encoding = "latin-1"))
agency <- dado$result
rm(dado)
agency <- agency %>% 
  select(agency_id, agency_name, agency_url, agency_timezone, agency_lang)
agency <- agency[agency$agency_id==20001,]
fwrite(agency,"./gtfs_brt/agency.txt")

# Frequ�ncias ----

##### Obtem dado usando API do SIGMOB. Seleciona a tabela de resultado. Remove tabela bruta.
##### Faz o filtro para manter apenas colunas desejadas. Mantem apenas modo BRT.
##### Escreve tabela filtrada.

dado <- fromJSON(getURL("http://jeap.rio.rj.gov.br/MOB/get_frequencies.rule?sys=MOB&INDICE=0",
                        .encoding = "latin-1"))

frequencies <- dado$result

rm(dado)

frequencies <- frequencies %>% 
  select(trip_id,start_time,end_time,headway_secs) 

frequencies <- frequencies[substr(frequencies$trip_id,1,2)==20 | substr(frequencies$trip_id,1,8)==22000016,]

fwrite(frequencies,"./gtfs_brt/frequencies.txt")

# Rotas ----

#### Obtem dado da API do SIGMOB e lanca resultado na tabela routes. Remove tabela bruta.

dado <- fromJSON(getURL("http://jeap.rio.rj.gov.br/MOB/get_routes.rule?sys=MOB&INDICE=0",
                        .encoding = "latin-1"))
routes <- dado$result
rm(dado)

#### Define campos fimVigencia e InicioVigencia como data/hora.
#### Preenche com valor padr�o nos casos omissos.

routes$fimVigencia <- as.POSIXct(routes$fimVigencia)
routes$fimVigencia[is.na(routes$fimVigencia)] <- as.POSIXct("2100-12-31")

routes$InicioVigencia <- as.POSIXct(routes$InicioVigencia)
routes$InicioVigencia[is.na(routes$InicioVigencia)] <- as.POSIXct("2010-11-01")

#### Define data de referencia para o GTFS.
#### Seleciona somente routes (servicos) vigentes na data de referencia.

dataReferenciaGTFS <- Sys.time()

routes <- routes %>% 
  filter(fimVigencia > dataReferenciaGTFS) %>% 
  filter(InicioVigencia < dataReferenciaGTFS)

rm(dataReferenciaGTFS)

#### Selecao de variaveis uteis para o GTFS. 
#### Uso de route_long_name como vista enquanto campo no SIGMOB nao for atualizado.

routes <- routes %>% mutate(route_long_name = Vista) %>% 
  select(agency_id,route_short_name,route_type,route_color,route_text_color,route_id,route_long_name) 

#### Remocao de # nos HEX das cores da linha e do texto da linha.

routes$route_color <- gsub('#','',routes$route_color)
routes$route_text_color <- gsub('#','',routes$route_text_color)

#### Selecao de rotas da agencia BRT Rio. Gravacao dos dados.

routes <- routes %>% 
  filter(agency_id==20001)
fwrite(routes,"./gtfs_brt/routes.txt")

# Stop Times, parte 1 ----

##### Obtem dado usando API do SIGMOB. Seleciona a tabela de resultado. Remove tabela bruta.
##### Mantem apenas modo BRT e linha SE01. Ordena tabela.
##### Faz o filtro para manter apenas colunas desejadas. 

stop_times <- data.frame()

dado <- fromJSON(getURL("http://jeap.rio.rj.gov.br/MOB/get_stop_times.rule?sys=MOB&INDICE=0",.encoding = "latin-1"))

stop_times <- dado$result

rm(dado)

stop_times <- stop_times[substr(stop_times$trip_id,1,2)==20  | substr(stop_times$trip_id,1,8)==22000016,]

stop_times <- arrange(stop_times,trip_id,stop_sequence)

stop_times <- stop_times %>% select(trip_id,stop_id,stop_sequence,arrival_time,departure_time,shape_dist_traveled)

# Stops ----

### Inicializacao de variaveis.

HaDados <- TRUE
i <- 0
stops <- data.table()

### Baixa dados enquanto a API retornar valores na pagina.
### Usa uma variavel para verificar tempo de download dos dados da API.

T1 <- Sys.time()

while(HaDados){
  print(i)
  url <- paste0("http://jeap.rio.rj.gov.br/MOB/get_stops.rule?sys=MOB&INDICE=",i)
  dado <- fromJSON(getURL(url,.encoding = "latin-1"))
  
  if(length(dado$data)>0){
    HaDados <- TRUE
  } else {
    HaDados <- FALSE
    next
  }
  
  if (nrow(stops)>0){
    dado <- dado$data %>% 
      select(stop_name,stop_id,stop_lat,stop_lon,location_type,idModalSmtr,
             IDTipoParada,Inexistente,parent_station)
    stops <- rbind(stops,dado)
  } else {
    dado <- dado$data %>% 
      select(stop_name,stop_id,stop_lat,stop_lon,location_type,idModalSmtr,
             IDTipoParada,Inexistente,parent_station)
    stops <- dado
  }
  i <- i+1
}

print(Sys.time()-T1)

### Remove dados ja utilizados.

rm(dado,HaDados,i,url,T1)

### Seleciona paradas com modo BRT.

### stops <- stops[substr(stops$stop_id,7,8) == 20, ]

##### Temporariamente desativado para manter paradas no SE 01.

### Seleciona paradas usadas (estao relacionadas no stop_times).
### Seleciona parent_station (nos de referencia das estacoes) das paradas usadas.
### Filtra somente paradas relacionadas no stop_times e seus respectivos parent_station.
### Remover variaveis nao utilizadas. Escrever tabela.

############ Para o futuro, usar apenas esta��es BRT abertas.

stops_used <- as.character(unique(stop_times$stop_id))
parent_stations_used <- stops$parent_station[stops$stop_id %in% stops_used]
stops_to_filter <- c(stops_used,parent_stations_used)
stops_to_filter <- unique(stops_to_filter)

stops <- stops %>% 
  filter(stop_id %in% stops_to_filter)

rm(stops_used,stops_to_filter,parent_stations_used)

# Calendario ----

### Download de dados da API e remocao de dados ja utilizados.

dado <- fromJSON(getURL("http://jeap.rio.rj.gov.br/MOB/get_calendar.rule?sys=MOB&INDICE=0",
                        .encoding = "latin-1"))
calendar <- dado$result
rm(dado)

### Preencher NA de dias com 0, para se adequar ao padrao do GTFS.

calendar[is.na(calendar)] <- 0

### Alterar service_id para valores human-friendly

calendar <- calendar %>% 
  mutate(service_id = case_when(service_id==100031 ~ "U",
                                service_id==100032 ~ "S",
                                service_id==100033 ~ "D",))

### Gravar resultados

fwrite(calendar,"./gtfs_brt/calendar.txt")

# Trips ----

### Inicializacao de variavel.

trips <- data.frame()

### Download de dados da API e remocao de dados ja utilizados.

dado <- fromJSON(getURL("http://jeap.rio.rj.gov.br/MOB/get_trips.rule?sys=MOB&INDICE=0",
                        .encoding = "latin-1"))

trips <- dado$result

rm(dado)

### Preencher service_id nulos por dia util (valor padrao).

trips$service_id[is.na(trips$service_id)] <- "U"

### Alterar service_id para valores human-friendly.

trips <- trips %>% 
  mutate(service_id = case_when(service_id==100031 ~ "U",
                                service_id==100032 ~ "S",
                                service_id==100033 ~ "D",
                                TRUE ~ service_id))

### Preencher shape_id nos casos omissos.

trips$shape_id[is.na(trips$shape_id)] <- trips$trip_id[is.na(trips$shape_id)]

### Selecao de colunas uteis para GTFS.
### Manutencao de trips associadas a rotas vigentes.
### Gravar dados.

trips <- trips %>% select(route_id,trip_headsign,trip_short_name,direction_id,trip_id,service_id,shape_id)
trips <- trips[trips$route_id %in% routes$route_id,]
fwrite(trips,"./gtfs_brt/trips.txt")

# Shapes ----

### Utilizar esta opcao se ja houver shapes no computador. Se nao, usar procedimento abaixo.

# shapes <- fread("./gtfs_rio/shapes.txt")

### Inicializacao de variaveis.

HaDados <- TRUE
i <- 0
shapes <- data.frame()

### Baixa dados enquanto a API retornar valores na pagina.

T1 <- Sys.time()

while(HaDados){
  print(i)
  url <- paste0("http://jeap.rio.rj.gov.br/MOB/get_shapes.rule?sys=MOB&INDICE=",i)
  dado <- fromJSON(getURL(url,.encoding = "latin-1"))
  
  if(length(dado$data)>0){
    HaDados <- TRUE
  } else {
    HaDados <- FALSE
    next
  }
  
  if (nrow(shapes)>0){
    shapes <- rbind(shapes,dado$data)
  } else {
    shapes <- dado$data
  }
  i <- i+1
}

print(Sys.time()-T1)

### Remocao de dados ja utilizados.

rm(T1,dado,HaDados,i,url)

### Selecionar somente shapes do BRT. (Desativado para manter SE 01.)

### shapes <- shapes[substr(shapes$shape_id,1,2)==20,]

### Usar somente stop_times de trips v�lidas.

shapes <- shapes[shapes$shape_id %in% trips$shape_id,]

### Selecionar colunas necessarias.
### Gravar dados.

shapes <- shapes %>% select(shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence,shape_dist_traveled)
fwrite(shapes,"./gtfs_brt/shapes.txt")

# Stop Times, parte 2 ----

### Usar somente stop_times de trips v�lidas.

stop_times <- stop_times[stop_times$trip_id %in% trips$trip_id,]

## Calcular tempo de paradas ----

### Ler tabela com velocidade por linha.

rotas <- fread("./velocidade_rotas.csv", colClasses = c("character","character","double","double"))

### Cria tabela paradas. 
### Traz o lat lon da tabela stops para calculo de distancia entre paradas.
### Traz a velocidade das linhas da tabela rotas para calculo de tempo de deslocamento.
### Preencher casos omissos na coluna `Inexistente`.
### (Coluna esta com nome invertido. Paradas com `Inexistente` == SIM sao paradas EXISTENTES.)

paradas <- stop_times %>% 
  left_join(select(stops, stop_id, stop_lat, stop_lon, parent_station, Inexistente,), by = "stop_id") %>% 
  mutate(route_id = substr(trip_id,1,11)) %>% 
  left_join(select(rotas, route_id, veloc_pico), by = "route_id") %>% 
  mutate(Inexistente = ifelse(is.na(Inexistente),"SIM",Inexistente))

### Remover tabela rotas.

rm(rotas)

### Adicionar velocidades em m/s para barcas e onibus intermunicipais (valores estimados).

paradas <- paradas %>% mutate(veloc_pico = case_when(substr(paradas$trip_id,1,2) == 30 ~ 6,
                                                     substr(paradas$trip_id,1,2) == 50 ~ 5.27,
                                                     substr(stop_times$trip_id,1,8)==22000016 ~ 10,
                                                     TRUE ~ veloc_pico))

### Zerar tempo de partida e chegada. Zerar distancia entre paradas.
### Zerar tempo entre paradas. Definir tempo de chegada e partida como variaveis de tempo.
### Zerar shape_dist_traveled. Selecionar modo da parada. Padronizar onibus como '22' (SPPO).
### Selecionar modo da viagem. Padronizar onibus como '22' (SPPO).
### Manter somente paradas que tem mesmo tipo de parada que a viagem. 
### (Util para desassociar paradas de STPL, STPC, etc.),
### Tirar paradas que nao existem. (IMPORTANTE, nome da coluna esta invertido.)
### Selecionar somente colunas uteis para calculos posteriores.

paradas <- paradas %>% 
  mutate(arrival_time = "00:00:00") %>% 
  mutate(departure_time = "00:00:00") %>% 
  mutate(distancia = 0) %>% 
  mutate(tempo = 0) %>% 
  mutate(arrival_time = as.ITime(arrival_time)) %>% 
  mutate(departure_time = as.ITime(departure_time)) %>% 
  mutate(shape_dist_traveled = as.numeric(0)) %>% 
  mutate(modo_parada = substr(stop_id,7,8)) %>% 
  mutate(modo_parada = case_when(modo_parada == "23" ~ "22",
                                 modo_parada == "30" ~ "22",
                                 modo_parada == "31" ~ "22",
                                 TRUE ~ modo_parada)) %>% 
  mutate(modo_trip = substr(trip_id,1,2)) %>% 
  mutate(modo_trip = case_when(modo_trip == "23" ~ "22",
                               modo_trip == "30" ~ "22",
                               modo_trip == "31" ~ "22",
                               TRUE ~ modo_trip)) %>% 
  filter(modo_parada == modo_trip) %>% 
  ### filter(Inexistente == 'SIM') %>% (Desativar por enquanto, rever depois.)
  select(trip_id,stop_id,stop_sequence,stop_lat,stop_lon,arrival_time,departure_time,
         shape_dist_traveled,parent_station,veloc_pico,distancia,tempo)

### Ordenar paradas pelo trip_id e stop_sequence.
### Reprocessa o stop_sequence, para preencher eventuais vazios apos remocao de 
### paradas inexistentes.

paradas <- arrange(paradas,trip_id,stop_sequence)

paradas <- paradas %>% 
  group_by(trip_id) %>% 
  dplyr::mutate(stop_sequence = 1:n()) %>% 
  ungroup()

### Transforma shapes e paradas em arquivo geografico (sf).

shapes <- st_as_sf(shapes,coords=c("shape_pt_lon","shape_pt_lat"),crs = 4326, remove = F, na.fail = T)
paradas <- st_as_sf(paradas,coords=c("stop_lon","stop_lat"),crs = 4326, remove = F, na.fail = T)

### Define valores padrao para as primeiras paradas de cada viagem.

paradas$shape_dist_traveled[paradas$stop_sequence == 1] <- 0

### Seleciona id de cada viagem.

id_trips <- unique(paradas$trip_id)

### Mantem somente campos necessarios.

paradas <- paradas %>% select(trip_id,stop_id,stop_sequence,arrival_time,departure_time,shape_dist_traveled,
                              veloc_pico,distancia,tempo)

### Inicializa df para recolher paradas ja processadas.

paradas_finished <- paradas[0,]

### Cria variaveis para verificar linhas que n�o passaram no metodo inicial.
### Util para monitorar linhas que podem ter erro nos shapes e/ou paradas associadas.

linhas_metodo1_primeiro <- NULL
linhas_metodo1_ultimo <- NULL
linhas_metodo2 <- NULL

### Inicializa variavel de contagem e de tempo de execucao.

j <- 1
T1 <- Sys.time()

### Executa enquanto j for menor que n�mero de viagens.
### (Ainda n�o achei uma maneira de fugir do for/while para acelerar a execucao).
### Talvez o caminho seja criar uma fun��o e usar apply, mas nao achei meio de fazer isso.

while (j <= length(id_trips)){
  
  ### Remove campos do processamento anterior. Limpa a memoria. 
  ### Mostra id da viagem em processamento.
  
  rm(a,b,c,g)
  gc()
  print(id_trips[j])
  
  ### Seleciona sequencia de paradas para processamento atraves do trip_id.
  ### Zera shape_dist_traveled e dist_shape.
  ### (dist_shape: distancia entre o ponto de parada e o shape da viagem.
  ### Util para verificar qualidade do metodo, problemas no shape ou nas paradas.)
  
  paradas_to_proc <- paradas[paradas$trip_id %like% id_trips[j],]
  paradas_to_proc$shape_dist_traveled <- NA
  paradas_to_proc$dist_shape <- 0
  
  ### a: seleciona shapes referentes a viagem.
  
  a <- shapes[shapes$shape_id==unique(paradas_to_proc$trip_id),]
  
  ### b: transforma shapes em linestring. 
  ### Reprojeta para sistema de coordenadas que � requisito para funcao executada posteriormete.
  
  b <- a %>% 
    summarise(do_union = FALSE) %>%
    st_cast("LINESTRING")
  b <- st_transform(b,32723)
  
  ### c: cria um ponto a cada metro do shape da viagem.
  
  c <- st_line_sample(b, density = 1/1) %>% 
    st_sf() %>%
    st_cast('POINT') %>%
    mutate(dist = 1:n())
  
  ### g: Busca o ponto c mais pr�ximo de cada parada da viagem.
  ### Converte g em data table e renomeia as colunas.
  ### Converte shape dist traveled em vari�vel numerica.
  ### (Como � gerado um ponto a cada metro do shape, o shape_dist_traveled � igual 
  ### ao numero do ponto c.)
  
  g <- nngeo::st_nn(st_transform(paradas_to_proc,32723),c, k = 1, returnDist = T)
  g <- as.data.table(g)
  colnames(g) <- c("shape_dist_traveled","dist_shape")
  g$shape_dist_traveled <- as.integer(g$shape_dist_traveled)
  g$dist_shape <- round(as.double(g$dist_shape),2)
  
  ### Calcula dist. E a distancia entre o ponto de parada e o ponto anterior, 
  ### sobre o shape da viagem. Define que NA, resultado no primeiro ponto de parada,
  ### recebe 0.
  
  g$dist <- g$shape_dist_traveled-lag(g$shape_dist_traveled)
  g <- g %>% 
    replace(is.na(.), 0)
  
  ### Se nao houver dist negativo, ou seja, se todos os pontos estiverem 
  ### a frente do ponto anterior, tudo esta certo. 
  ### Neste caso, shape_dist_traveled e dist_shape s�o preenchidos e o processo
  ### se encerra, avancando para a proxima viagem.
  
  if (nrow(g[g$dist<0,]) == 0){
    paradas_to_proc$shape_dist_traveled <- g$shape_dist_traveled
    paradas_to_proc$dist_shape <- g$dist_shape
    
    ### Se houver dist negativo, avancar para proxima etapa.
  } else {
    
    ### Criar campo parada, para obter ordem das paradas.
    
    g <- g %>% mutate(parada = 1:n())
    
    ### Criar objeto m, para verificar quantas paradas est�o � frente de uma parada posterior.
    
    m <- g[lead(g$dist<0,)]
    
    ### Se houver apenas uma parada � frente de uma parada posterior,
    if (nrow(m) == 1){
      print(id_trips[j])
      
      ### Verificar se ela � a �ltima.
      
      if (tail(g$parada,1)==g$parada[g$dist<0]){
        
        ### Criar objeto h, pegando �ltima parada.
        
        h <- tail(g,1)
        
        ### Zerar dist�ncia para o shape desta parada.
        
        h$dist_shape <- 0
        
        ### Separar �ltima parada das demais.
        
        l <- anti_join(g,h)
        
        ### Informar que est� se usando este m�todo para o caso de �ltima parada
        ### e adicionar o id da trip na lista.
        
        print("M�todo 1 - Ultimo")
        linhas_metodo1_ultimo <- c(linhas_metodo1_ultimo,id_trips[j])
        
        ### Criar objeto d, pegando o fim do shape.
        
        d <- tail(c,1)
        
        ### Usar distancia do �ltimo ponto como shape_dist_traveled da �ltima parada,
        ### e calcular dist�ncia entre a �ltima parada e o �ltimo ponto do shape.
        ### (�til para avaliar se o m�todo funcionou bem ou se as dist�ncias ficaram muito grandes).
        h$shape_dist_traveled <- d$dist
        h$dist_shape <- round(as.double(st_distance(st_transform(tail(paradas_to_proc,1), 32723), d)),2)
        h$dist_shape <- round(as.double(h$dist_shape),2)
        
        ### Recriar o arquivo g, associando as demais paradas � �ltima parada,
        ### e reprocessando o campo dist entre a parada e a parada anterior.
        g <- bind_rows(h,l) %>% 
          arrange(parada) %>% 
          mutate(dist = shape_dist_traveled-lag(shape_dist_traveled)) %>% 
          replace(is.na(.), 0)
      }
      
      ### Verificar se ela � a primeira.
      
      if (m$parada == 1){
        
        ### Criar objeto h, pegando primeira parada.
        h <- g[lead(g$dist<0,)]
        
        ### Zerar dist�ncia para o shape desta parada.
        
        h$dist_shape <- 0
        
        ### Separar primeira parada das demais.
        
        l <- anti_join(g,h)
        
        ### Informar que est� se usando este m�todo para o caso de primeira parada
        ### e adicionar o id da trip na lista.

        print("M�todo 1 - Primeiro")
        linhas_metodo1_primeiro <- c(linhas_metodo1_ultimo,id_trips[j])
        
        ### Se a dist�ncia entre a primeira parada e o primeiro n� do shape for
        ### menor que a distancia para o segundo n� do shape, assumir que o n� do shape 
        ### de primeira parada � o n� da primeira parada.
        ### Se n�o, pegar o n� do shape mais pr�ximo da primeira parada.
        
        if (st_distance(st_transform(paradas_to_proc[1,], 32723), c[1,])<st_distance(st_transform(paradas_to_proc[1,], 32723), c[2,])){
          d <- c[c$dist==1,]
        } else {
          d <- c[order(st_distance(st_transform(paradas_to_proc[1,], 32723), c)),] %>% 
            mutate(posicoes = 1:n()) %>% 
            slice_head(n = 1)
        }
        
        ### Usar dist�ncia do primeiro n� do shape ou n� mais pr�ximo, conforme resultado do if acima.
        ### Calcular dist�ncia entre a primeira parada e o ponto do shape selecionado.
        ### (�til para avaliar se o m�todo funcionou bem ou se as dist�ncias ficaram muito grandes).
        h$shape_dist_traveled <- d$dist
        h$dist_shape <- round(as.double(st_distance(st_transform(paradas_to_proc[1,], 32723), d)),2)
        h$dist_shape <- round(as.double(h$dist_shape),2)
        
        ### Recriar o arquivo g, associando a primeira parada �s demais paradas
        ### e reprocessando o campo dist entre a parada e a parada anterior.
        
        g <- bind_rows(h,l) %>% 
          arrange(parada) %>% 
          mutate(dist = shape_dist_traveled-lag(shape_dist_traveled)) %>% 
          replace(is.na(.), 0)
      }
    }
    
    ### Se nao houver dist negativo, ou seja, se todos os pontos estiverem 
    ### a frente do ponto anterior, o metodo 1 funcionou.
    ### Neste caso, shape_dist_traveled e dist_shape s�o preenchidos e o processo
    ### se encerra, avancando para a proxima viagem.
    
    if (nrow(g[g$dist<0,]) == 0){
      paradas_to_proc$shape_dist_traveled <- g$shape_dist_traveled
      paradas_to_proc$dist_shape <- g$dist_shape
    } else {
      
      ### Caso contr�rio, inicia-se o m�todo 2.
      
      linhas_metodo2 <- c(linhas_metodo2,id_trips[j])
      for (i in 1:nrow(paradas_to_proc)){
        
        ### Caso o tryCatch fique ativo, pode haver shape_dist_traveled == NA no fim da execu��o. 
        ### Fazer teste para validar o resultado. Se ele for inativado, corre o risco de quebrar
        ### a execu��o muitas vezes, exigindo maior aten��o do operador para acompanhar execu��o 
        ### do c�digo.
        tryCatch({
          
          ### Mostrar que est� sendo usado o m�todo 2, mostrar a trip processada e a ordem da parada.
          
          print("Metodo 2")
          print(id_trips[j])
          print(j)
          print(i)
          
          
          if (i == 1){
            
            ### Se a dist�ncia entre a primeira parada e o primeiro n� do shape for
            ### menor que a distancia para o segundo n� do shape, assumir que o n� do shape 
            ### de primeira parada � o n� da primeira parada.
            ### Se n�o, pegar o n� do shape mais pr�ximo da primeira parada.
            
            if (st_distance(st_transform(paradas_to_proc[1,], 32723), c[1,])<st_distance(st_transform(paradas_to_proc[1,], 32723), c[2,])){
              d <- c[c$dist==1,]
            } else {
              d <- c[order(st_distance(st_transform(paradas_to_proc[1,], 32723), c)),] %>% 
                mutate(posicoes = 1:n()) %>% 
                slice_head(n = 1)
            }
            paradas_to_proc[i,]$shape_dist_traveled <- d$dist
            paradas_to_proc[i,]$dist_shape <- round(as.double(st_distance(st_transform(paradas_to_proc[i,], 32723), d)),2)
          } else {
            
            ### c: recebe os n�s do shape (1 a 1 metro) com ordem maior 
            ### que o n� associado � parada anterior.
            
            c <- c[c$dist>paradas_to_proc[i-1,]$shape_dist_traveled,]
            
            ### d: Ordena cada n� do shape em rela��o � dist�ncia com a parada em quest�o.
            
            d <- c[order(st_distance(st_transform(paradas_to_proc[i,], 32723), c)),] %>% 
              ### Cria um campo posicoes para saber a ordem de proximidade do n� 
              ### em rela��o � parada (1 � o mais pr�ximo, 2 � o segundo mais pr�ximo...)
              mutate(posicoes = 1:n()) %>% 
              ### Seleciona os tres n�s mais pr�ximos.
              filter(posicoes < 4) %>% 
              ### Ordena pelo campo dist (distancia entre primeiro n� do shape e o n� atual)
              ### Ou seja, d� prioridade aos n�s no in�cio do shape.
              arrange(dist) %>% 
              ### Cria campo dist_rel, dist�ncia do n� em rela��o ao n� anterior (ordenado pela
              ### distancia em relacao ao inicio).
              mutate(dist_rel = dist-lag(dist)) %>% 
              ### Troca NA por 0, para o caso do primeiro n�.
              replace(is.na(.), 0) %>% 
              ### Remove �queles com dist_rel maior que 3. Ou seja, caso os n�s mais pr�ximos
              ### de uma parada sejam o 1500, o 1501 e o 29000, o 29000 ser� removido porque
              ### a dist_rel dele ser� 29000 - 1501 = 27499.
              filter(dist_rel < 4) %>% 
              ### Ordena valores restantes pelas posicoes em relacao � proximidade com parada.
              ### Assim, caso o n� mais pr�ximo seja o 1501, ele entra na frente do 1500.
              arrange(posicoes) %>% 
              ### Seleciona o n� mais pr�ximo.
              slice_head(n = 1)
            
            ### Associa os valores de d � parada relacionada. Remove d.
            paradas_to_proc[i,]$shape_dist_traveled <- d$dist
            paradas_to_proc[i,]$dist_shape <- round(as.double(st_distance(st_transform(paradas_to_proc[i,], 32723), d)),2)
            rm(d)
          }
        }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
      }
    }
  }
  
  ### Adiciona paradas da trip ao dataframe com as paradas das viagens j� processadas.
  paradas_finished <- bind_rows(paradas_finished,paradas_to_proc)
  j <- j+1
}


### Exibe tempo de execucao e remove variaveis.

print(Sys.time()-T1)
rm(T1,a,b,c,d,g,h,i,j,l,m,paradas_to_proc,id_trips)

### Verifica se alguma parada ficou sem n� de shape associado.

revisao <- paradas_finished %>% 
  group_by(trip_id) %>% 
  filter(any(is.na(shape_dist_traveled))) %>% 
  ungroup()

if (nrow(revisao) > 0){
  print("REVER EXECU��O. ERRO. PARADAS SEM SHAPE_DIST_TRAVELED.")
  beepr::beep()
  Sys.sleep(0.5)
  beepr::beep()
  Sys.sleep(0.5)
  beepr::beep()
}

### Define distancia m�xima aceita entre parada e n� do shape.

dist_maxima_aceita <- 200

### Verifica se alguma parada ficou com n� de shape associado muito distante.

revisao <- paradas_finished %>% 
  group_by(trip_id) %>% 
  filter(dist_shape > dist_maxima_aceita) %>% 
  ungroup()

if (nrow(revisao) > 0){
  print(paste("REVER EXECU��O. ALERTA. HA",nrow(revisao),"PARADAS COM DISTANCIA DO SHAPE MAIOR QUE",
              dist_maxima_aceita," METROS."))
  beepr::beep()
  Sys.sleep(0.5)
  beepr::beep()
}

rm(dist_maxima_aceita,revisao)

### Substitui tabela paradas por paradas_finished. Remove paradas_finished.

paradas <- paradas_finished

rm(paradas_finished)

### Cria valor distancia, que � a distancia percorrida entre a parada e a parada anterior.
### Remove todas as paradas cuja dist�ncia para a parada anterior seja igual a 0, 
### desde que n�o seja a primeira parada da viagem.
### (�til para limpar eventuais erros de paradas associadas duas vezes.)
### Reprocessa o stop_sequence.
### Cria valor tempo, que � dist�ncia em metros dividida por velocidade m�dia 
### da linha/grupo da linha em metros por segundo.
### Cria valor arrival_time (tempo de chegada), que � a soma cumulativa dos tempos de viagem anteriores.
### Cria valor departute_time, que recebe arrival_time.

paradas <- paradas %>% 
  group_by(trip_id) %>% 
  mutate(distancia = ifelse(stop_sequence == 1, 0, shape_dist_traveled - lag(shape_dist_traveled))) %>% 
  filter(distancia != 0 | stop_sequence == 1) %>% 
  mutate(stop_sequence = 1:n()) %>% 
  mutate(tempo = distancia/veloc_pico) %>% 
  mutate(arrival_time = as.ITime(cumsum(tempo))) %>%
  mutate(departure_time = arrival_time)

### Transforma arrival_time e departure_time em tipo caractere.

paradas$arrival_time <- as.character(paradas$arrival_time)
paradas$departure_time <- as.character(paradas$departure_time)

### Seleciona colunas uteis para GTFS e define stop_times como paradas.
### Remove tabela paradas.

stop_times <- as.data.table(paradas)
stop_times <- stop_times %>% select(trip_id,arrival_time,departure_time,stop_id,shape_dist_traveled,stop_sequence)

rm(paradas)

### Salva sequencia de paradas (stop_times)

fwrite(stop_times,"./gtfs_brt/stop_times.txt")

### Salvar stops ----

### Seleciona apenas colunas �teis para o GTFS e grava os dados.
stops <- stops %>% select(stop_id,stop_name,stop_lat,stop_lon,location_type
                          ,parent_station)

fwrite(stops,"./gtfs_brt/stops.txt")

